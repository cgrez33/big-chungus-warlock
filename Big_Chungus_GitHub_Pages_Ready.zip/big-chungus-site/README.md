# Big Chungus Warlock Command Center

Static offline-capable WoW Forever Warlock leveling dashboard.

## Publish with GitHub Pages
1. Create a public repository named `big-chungus-warlock`.
2. Upload `index.html` to the repository root.
3. In **Settings → Pages**, choose **Deploy from a branch**, **main**, **/(root)** and save.
4. Your site will be available at `https://YOUR-USERNAME.github.io/big-chungus-warlock/` after deployment.

Note: checklist progress is saved locally per browser/device and does not sync between devices.
